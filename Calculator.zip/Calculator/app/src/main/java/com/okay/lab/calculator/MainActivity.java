package com.okay.lab.calculator;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onClick(View v)
    {
        EditText res = findViewById(R.id.editText);
        Button b = findViewById(v.getId());
        String ch  = b.getText().toString();
        switch(ch)
        {
            case "=":
                s = res.getText().toString();
                int i =0,pos=0,n;
                while(s.charAt(i)!='\0') {
                    char a = s.charAt(i);
                    if(a=='+')
                    {
                      pos = i;
                    }
                    i+=1;
                }
                n =  i;
                int n1 = Integer.parseInt(s.substring(0,pos-1));
                int n2 = Integer.parseInt(s.substring(pos+1,n));
                Toast.makeText(MainActivity.this,Integer.toString(n1+n2),Toast.LENGTH_SHORT).show();


            break;
            default:
                s = res.getText().toString();
                s = s+ch;
                res.setText(s);
            break;
        }
    }
}
